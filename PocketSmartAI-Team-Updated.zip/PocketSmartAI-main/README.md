# PocketSmart AI — Your Smart Budget & Recommedation Assistant

Repository Structure

1.Brainstorming & Ideation

2.Requirement Analysis

3.Project Design Phase

4.Project Planning Phase

5.Project Development Phase

6.Project Testing

7.Project Documentation

8.Project Demonstration

Replace the placeholder files with your team's project deliverables.
